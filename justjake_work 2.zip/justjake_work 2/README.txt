Just Jake — simplified structure
================================

Changes in this version:
- Removed the homepage Quick Wins and Chaos Tax sections.
- Featured the six selected interactive tools on the homepage.
- Kept Website Setup and People Hub prominent.
- Promoted About Jake and FAQs in the main navigation.
- Embedded the supplied Tally contact form on the homepage.
- Removed the location from every footer.
- Replaced the large footer with a simpler footer.
- Added a footer-only More tools & resources page for Brand Colour Picker,
  Business in a Box, and Systems Setup & Automation.
- Removed all public links to Services and added noindex,nofollow to that page.
  The Services source file remains available for later reworking.

Upload the contents of the JustJake folder to the existing static host.
Brand consistency update:
- assets/brand.css is the shared homepage-aligned brand layer used by every page.
- Tool-generated colour swatches remain intentionally unchanged.
